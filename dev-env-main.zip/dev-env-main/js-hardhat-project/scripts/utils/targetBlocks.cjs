

module.exports = {

    primary: 19000000

}
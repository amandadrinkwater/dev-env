

module.exports = {

    localHardHat: "http://127.0.0.1:8545",
    mainnetInfura: "https://mainnet.infura.io/v3/872f2cefb20044c2be4b9930e8aa69a0"

};